document.addEventListener('DOMContentLoaded', () => {
    const synth = window.speechSynthesis;

    if (!synth) {
        console.error('Seu navegador não suporta a Web Speech API.');
        return;
    }

    const speakText = (text) => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pt-BR';
        synth.speak(utterance);
    };

    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        section.addEventListener('focus', () => {
            speakText(section.querySelector('h2').textContent + '. ' + section.querySelector('p').textContent);
        });
    });

    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('focus', () => {
            speakText('Link para ' + link.textContent);
        });
    });
});
